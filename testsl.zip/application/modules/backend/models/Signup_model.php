<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Signup_model extends CI_Model {

  private $table = "gallery_info";
	//private $_data = array();

	public function save($data){
		$result = $this->db->insert($this->table,$data);
		if($result){
			return $this->db->insert_id();
		}else{
			return $result;
		}
  }
  public function saveimage($data){
	$result = $this->db->insert('image_gallery',$data);
	if($result){
		return $this->db->insert_id();
	}else{
		return $result;
	}
}
public function getAll(){

	$this->db->select('*'); 
		$this->db->from('image_gallery');
		$query = $this->db->get();
		return $query->result_array();
		}
		public function get_count() 
		{
			// return $this->db->count_all("image_gallery");

			$this->db->select("count(*) as CNT"); 
			$qry = $this->db->get("image_gallery");
			$result2 = $qry->row()->CNT;
			return $result2;
		}
	
		public function get_i($limit, $start) 
		{
			$this->db->limit($limit, $start);
			$query = $this->db->get("image_gallery");
			return $query->result_array();
		}
}