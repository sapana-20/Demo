<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<title>Send Us Your Best Photos!</title>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Arimo:400,400i,700,700i&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/owl.css" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/color.css" rel="stylesheet">
<link href="assets/css/rtl.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">
<style>
img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}

img:hover {
  box-shadow: 0 0 2px 1px rgba(0, 140, 186, 0.5);
}
</style>
</head>
<!-- page wrapper -->
<body class="boxed_wrapper ltr">

    <!-- Preloader -->
    <div class="loader-wrap">
        <div class="preloader"><div class="preloader-close">Preloader Close</div></div>
        <div class="layer layer-one"><span class="overlay"></span></div>
        <div class="layer layer-two"><span class="overlay"></span></div>        
        <div class="layer layer-three"><span class="overlay"></span></div>        
    </div>
    <!-- main header -->
    <header class="main-header style-one style-six">
        

        <!--sticky Header-->

    </header>
    <!-- main-header end -->

    <!-- Mobile Menu  -->
    <div class="mobile-menu">
        <div class="menu-backdrop"></div>
        <div class="close-btn"><i class="fas fa-times"></i></div>
        
        <nav class="menu-box">
            <div class="nav-logo"><a href="index.html"><img src="assets/images/small-logo.png" alt="" title=""></a></div>
            <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
            <div class="contact-info">
                <h4>Contact Info</h4>
                <ul>
                    <li>838 New Street, Maharashtra, India 413005</li>
                    <li><a href="tel:+9101682648101">+91 201682 648101</a></li>
                    <li><a href="mailto:info@example.com">info@travels.com</a></li>
                </ul>
            </div>
            <div class="social-links">
                <ul class="clearfix">
                    <li><a href="index.html"><span class="fab fa-twitter"></span></a></li>
                    <li><a href="index.html"><span class="fab fa-facebook-square"></span></a></li>
                    <li><a href="index.html"><span class="fab fa-pinterest-p"></span></a></li>
                    <li><a href="index.html"><span class="fab fa-instagram"></span></a></li>
                    <li><a href="index.html"><span class="fab fa-youtube"></span></a></li>
                </ul>
            </div>
        </nav>
    </div><!-- End Mobile Menu -->


    <!--Page Title-->
    
    <section class="about-style-four">
        <div class="auto-container">
            <br>
        <?php $error = $this->session->flashdata("error");unset($_SESSION['error']); ?>
      <?php if($error){?>
        <div class="row">
          <div class="col-md-12">
            <div class="alert alert-danger alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <?php echo $error ?>
            </div>
          </div>
        </div>								
      <?php } ?>
      <?php $success = $this->session->flashdata("success");unset($_SESSION['success']); ?>
      <?php if($success){?>
        <div class="row">
          <div class="col-md-12">
            <div class="alert alert-success alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <?php echo $success ?>
            </div>
          </div>
        </div>								
      <?php } ?>
            <div class="row clearfix">
                
                <div class="col-xl-12">
                <div class="visa-form-box">
                    <div class="title">
                        <h2><span>Send Us Your Best Photos!</span></h2>
                    </div>
                    <!-- <form id="visa-form" name="visa_form" class="default-form2" action="#" method="post"> -->
                    <?php echo form_open_multipart(''); ?> 
                    <div class="row">
                            <div class="col-xl-12 col-lg-12">
                                <div class="input-box"> 
                                    <label>Your Name</label>
                                    <input type="text" name="username" value="" placeholder="Name" required="">
                                    <div class="icon"><span class="flaticon-user"></span></div> 
                                </div>
								<div class="input-box"> 
                                    <label for="">Email Address</label>
                                    <input type="email" name="email_id" value="" placeholder="E-mail ID" required="">
                                    <div class="icon"><span class="flaticon-user"></span></div> 
                                </div>
                                <!-- <div class="input-box"> 
                                    <label for="">File Upload</label>
                                    <input type="file" name="image_path[]" multiple value="" placeholder="Image" required="">
                                    <div class="icon"><span class="flaticon-user"></span></div> 
                                </div> -->
                                <!--  -->
                                <div class="row"   id="inward_row" >
            <div class="col-md-12">
              <table class="table table-bordered table-responsive">
                <thead class="text-center">
                  <tr>
                    <th> Sr.</th>
                    <th> File Upload </th>
                    <th> </th>
                  </tr>
                </thead>
                <tbody class="add_more_row_inward_particular">
                  
                  <tr id="1">
                    <td>1</td>
                    <td><input type="file" name="image_path[]" multiple="" class="form-control" title="Resort Image"/></td>
                    <td><a href="javascript:void(0);" class="add_button_inward" title="Add field"><i class="fa fa-plus-circle text-primary"></i>Add Another</a></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

                                <!--  -->
								
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-xl-12">
                                <div class="button-box">
                                    <button class="btn-one" id="submit"  type="submit">
                                        <span class="txt">Continue</span>
                                    </button>    
                                </div>      
                            </div>
                        </div> 
                   
                        <?php echo form_close(); ?>
                        <!-- </form> -->
                </div>    
            </div>

            <div class="title" style="margin-left:32%;">
                        <h5><span><a href="<?php echo base_url("backend/Signup/view");?>">Click Here To Show Gallery Images</a></span></h5>
                    </div>
            
                   
            </div>
            
        </div>
    </section>
    <!-- about-style-four end -->


<!-- jequery plugins -->
<script src="assets/js/jquery.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/owl.js"></script>
<script src="assets/js/wow.js"></script>
<script src="assets/js/validation.js"></script>
<script src="assets/js/jquery.fancybox.js"></script>
<script src="assets/js/appear.js"></script>
<script src="assets/js/jquery.countTo.js"></script>
<script src="assets/js/scrollbar.js"></script>
<script src="assets/js/nav-tool.js"></script>
<script src="assets/js/TweenMax.min.js"></script>
<script src="assets/js/circle-progress.js"></script>
<script src="assets/js/jquery.nice-select.min.js"></script>

<!-- main-js -->
<script src="assets/js/script.js"></script>
<script type="text/javascript">
      $(document).ready(function(){
          var addButton = $('.add_button_inward'); //Add button selector
          var wrapper = $('.add_more_row_inward_particular'); //Input field wrapper
          var z = 1;
          //Once add button is clicked
          $(addButton).click(function(){
            z++;
                  var fieldHTML = '<tr class="'+z+'"><td>'+ z +'</td><td><input type="file" name="image_path[]" multiple="" class="form-control" title="Resort Image"/></td><td><a href="javascript:void(0);" data-id="'+z+'" class="remove_button_inward" title="Add field"><i class="fa fa-minus-circle text-danger"></i>Delete</a></td></tr>'; 
                  $(wrapper).append(fieldHTML); //Add field html
          });
          //Once remove button is clicked
          $(wrapper).on('click', '.remove_button_inward', function(e){
              e.preventDefault();
              
              $('.' + $(this).data('id')).remove();
              // $(this).parent('tr').remove(); //Remove field html
              // x--; //Decrement field counter
          });
      });
    </script>
</body><!-- End of .page_wrapper -->
</html>
