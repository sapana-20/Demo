<div class="title" style="margin-left:32%;">
                        <h1><span>Thumbnail View</span></h1>
                    </div>
            <div class="row">
            
                            <div class="col-xl-12">
                                
                            <?php foreach ($gallery as  $value) { ?>
                            <a target="_blank" href="<?php echo base_url()?>uploads/slider/<?php echo $value['image_path']?>">
                            <img src="<?php echo base_url()?>uploads/slider/<?php echo $value['image_path']?>" style="height:150px; width:150px">
  <!-- <img src="img_forest.jpg" alt="Forest" style="width:150px"> -->
</a>

<?php }?>
      
                            </div>
                        </div> 
                        <br/>
                        <div class="pagination">
    <ul>
        <?php 
    // echo $pagination->create_links()
        ?>
    </ul>    
</div>
                       <p class="col-xl-12"><?php echo $links; ?></p> 