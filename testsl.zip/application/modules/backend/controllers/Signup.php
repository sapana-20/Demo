<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends MY_Controller {
	
	public function add()
	{
	  $this->load->library('form_validation');
      $this->form_validation->set_rules("username", "Username", "required");
      $this->form_validation->set_rules("email_id", "Email_id", "required");
      
      if($this->form_validation->run()==TRUE)
     {
        //  if($this->input->post('password')==$this->input->post('confirmpassword'))
        //  {
            $saveData = array(
                'name' => $this->input->post('username'),
                'email_id' => $this->input->post('email_id')
              );
              $this->load->model('Signup_model');
              $res=$this->Signup_model->save($saveData);
              if($res)
              {
             //-----1------
             for($i=0;$i<count($_FILES['image_path']['name']);$i++)
             {
                $new_imageE = '';
                if(!empty($_FILES['image_path']['name'][$i])) {
                  // $opt__name = 'imagegallery_path';
                  $imageE = $_FILES['image_path']['name'][$i];
                  $opp = pathinfo($_FILES['image_path']['name'][$i], PATHINFO_FILENAME);
                  $rand=rand(10000,99999);
                  $imageExtension = @end(explode('.',$imageE));
                  $imagetemp = strtolower($imageExtension);
                  $new_imageE=$rand.'.'.$imagetemp;
                  $image_path='./uploads/slider/'.$new_imageE;
                  move_uploaded_file($_FILES['image_path']['tmp_name'][$i],$image_path);
                
   
    }
	//-----1-----
            

              $saveimage = array(
                'galleryinfo_id' => $res,
                'image_path' => $new_imageE
              );

             $resimgae=$this->Signup_model->saveimage($saveimage);
            }
        }
         
        
        
        if($res){
            $this->session->set_flashdata('success', "Inserted Successfully");
            return redirect(base_url('signup'));
        } else {
            $this->session->set_flashdata('error', "Somethings went wrong! Please try again.");
        }
          
    //   }
    //   else{
    //     $this->session->set_flashdata('error', "Enter Correct Confirm Password");
    //   }
    }
    
	
     $data['page_title'] = "Add Signup";
    
		//$this->load->view('layout/header');
		//$this->load->view('layout/sidemenu');
		//$this->load->view('layout/breadcrumb',$data);
		$this->load->view('signup/add',$data);
		//$this->load->view('layout/footer');
   

	}

  public function view()
	{ 
    $this->load->model('Signup_model');
	$data['imagegallery']=$this->Signup_model->getAll();
	
  // ------
  $this->load->library("pagination");

  $this->load->model('Signup_model');
$config = array();
        $config["base_url"] = base_url() .'backend/Signup/view/';;
        $config["total_rows"] = $this->Signup_model->get_count();
        // print_r($config["total_rows"]);
        // exit;
        $config["per_page"] = 12;
        $config["uri_segment"] = 3;

        
        $this->pagination->initialize($config);

		
		$page = ($this->uri->segment(3))? $this->uri->segment(3) : 0;
		
        $data["links"] = $this->pagination->create_links();

        $data['gallery'] = $this->Signup_model->get_i($config["per_page"], $page);
// ----


		$this->load->view('signup/view',$data);
	}
}