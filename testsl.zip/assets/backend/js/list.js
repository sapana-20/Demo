$('#generateListText').keyup(function (e) {
	$('#selectedId').val('');
	if (e.which == 40) {
		if ($("#generateList li.active").length != 0) {
			var storeTarget = $('#generateList').find("li.active").next();
			$("#generateList li.active").removeClass("active");
			storeTarget.focus().addClass("active");
		} else {
			$('#generateList').find("li:first").focus().addClass("active");
		}
		return;
	}

	if (e.which == 38) {
		if ($("#generateList li.active").length != 0) {
			var storeTarget = $('#generateList').find("li.active").prev();
			$("#generateList li.active").removeClass("active");
			storeTarget.focus().addClass("active");
		} else {
			$('#generateList').find("li:first").focus().addClass("active");
		}
		return;
	}

	if (e.which == 13) {
		var selectedId = $('#generateList').find("li.active").attr('id');
		if (selectedId != undefined) {
			$('#selectedId').val(selectedId);
			$('#generateListText').val($('#' + selectedId).data('text'));
			$('#generateList').html('');

			// if ($('#generateListText').data('get')) {
			// 	$.ajax({
			// 		url: $('#generateListText').data('get'),
			// 		type: 'post',
			// 		dataType: 'json',
			// 		data: {
			// 			'title_id': selectedId
			// 		},
			// 		success: function (result) {
			// 			console.log(result);
			// 			$('#phone').val(result.mobile);
			// 			$('#email').val(result.email_id);
			// 		}
			// 	});
			// }

		}
		return;
	}

	$.ajax({
		url: $("#listurl").val(),
		type: 'post',
		data: {
			'generateListText': $(this).val(),
			'selectModel': $('#selectModel').val()
		},
		success: function (result) {
			$('#generateList').html(result);
		},

	});

});

function setGeneratedText(generatedTextId) {
	$('#selectedId').val(generatedTextId);
	$('#generateListText').val($('#' + generatedTextId).data('text'));
	$('#generateList').html('');

	// if ($('#generateListText').data('get')) {
	// 	$.ajax({
	// 		url: $('#generateListText').data('get'),
	// 		type: 'post',
	// 		dataType: 'json',
	// 		data: {
	// 			'doctor_id': generatedTextId
	// 		},
	// 		success: function (result) {
	// 			// console.log(result);
	// 			$('#phone').val(result.mobile);
	// 			$('#email').val(result.email_id);
	// 		}
	// 	});
	// }

}
