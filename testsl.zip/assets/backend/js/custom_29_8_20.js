function getDetails(row_id) {
    var color_chemical_id = $('#' + row_id).find('.color_chemical_name').val();
    $('#' + row_id).find('.rate').val(0);
    $.ajax({
        url: $('#url').val(),
        type: 'post',
        dataType: 'json',
        data: {
            'color_id': color_chemical_id
        },
        success: function(result) {
            // console.log(result);
            $('#' + row_id).find('.rate').val(result);
            //$('#email').val(result.email_id);
        }
    });
}



function rateFunction(rowsid) {
    $(document).on('change', '.change', function() {
        var number = parseFloat($('#' + rowsid).find('.rate').val()) * parseFloat($('#' + rowsid).find('.qty').val());
        $('#' + rowsid).find('.total').val(number);
    });
}

function partiFunction(partirowsid) {
    $(document).on('partichange', '.partichange', function() {
        var number_parti = parseFloat($('#' + partirowsid).find('.parti_qty').val()) * parseFloat($('#' + partirowsid).find('.parti_total').val());
        $('#' + partirowsid).find('.parti_subtotal').val(number_parti);
    });
}


function getTotal(row_id, opt) {
    var price = $('.opt_' + opt + '_' + row_id).find('.color_name_opt_' + opt).children("option:selected").data('price');
    var qty = $('.opt_' + opt + '_' + row_id).find('.qty_opt_' + opt).val();
    if(qty != undefined && price != undefined) {
        amt = price * qty;
        $('.opt_' + opt + '_' + row_id).find('.total_' + opt).val(amt.toFixed(2) );
        $('.opt_' + opt + '_' + row_id).find('.total_opt_' + opt).val(amt.toFixed(2) );
        var totalamt = 0;
        $('.add_more_row_shed_opt_' + opt ).find('input[type=hidden]').each(function(){
            var amtt = $(this).val();
            totalamt = (parseFloat(totalamt) + parseFloat(amtt));
        });

        $('#opt_total_' + opt).val(totalamt.toFixed(2));
        $('#opt_' + opt + '_total').val(totalamt.toFixed(2));
        
        if($('#opt_' + opt + '_per').val() != "" && $('#opt_' + opt + '_per').val() != undefined) {
            peraddition = (parseFloat(totalamt) * parseFloat($('#opt_' + opt + '_per').val())) / 100;
            $('#opt_total_' + opt).val((parseFloat(totalamt) + parseFloat(peraddition)).toFixed(2));
            $('#opt_' + opt + '_total').val((parseFloat(totalamt) + parseFloat(peraddition)).toFixed(2));
        }
    }
}
function getoutwardDetails(rowget_id) {

    var job_card_no_id = $('#' + rowget_id).find('.job_card_no').val();
    $('#' + rowget_id).find('.particular').val(0);
    //alert(job_card_no_id);
    $.ajax({
        type: 'post',
        url: $('#url_jobid').val(),
        dataType: 'text',
        data: {
            'job_typeid': job_card_no_id
        },
        success: function(result) {
            // console.log(result);
            //alert(result);
            $('#' + rowget_id).find('.particular').val(result);
            //$('#' + rowget_id).find('.gray_weight').val(result);
            // $('#particular').val(result.job_type);
        }
    });
    $.ajax({
        type: 'post',
        url: $('#url_grayid').val(),
        dataType: 'text',
        data: {
            'job_typeid': job_card_no_id
        },
        success: function(result) {
            // console.log(result);
            //alert(result);
            $('#' + rowget_id).find('.gray_weight').val(result);
            //$('#' + rowget_id).find('.gray_weight').val(result);
            // $('#particular').val(result.job_type);
        }
    });
}

function weightFunction(rowsoutwardid) {
    $(document).on('change', '.weightchange', function() {
        var number = parseFloat($('#' + rowsoutwardid).find('.gray_weight').val()) - parseFloat($('#' + rowsoutwardid).find('.delivery_weight').val());
        $('#' + rowsoutwardid).find('.weight_loss').val(number);
    });
}